<?php
if(!defined('IN_PLUGIN'))exit();

$order = $DB->getRow("SELECT * FROM pre_order WHERE trade_no='{$trade_no}' LIMIT 1");
$typename = $DB->getColumn("SELECT name FROM pre_type WHERE id='{$order['type']}' LIMIT 1");
if($typename == 'wxpay'){
    $type = 1;
}
if($typename == 'alipay'){
    $type = 2;
}
$data = array(
	'payId'=>TRADE_NO,
	'type'=>$type,
	'price'=>$order['money'],
	'isHtml'=>'1',
	"notifyUrl" => $siteurl.'pay/vpay/notify/'.TRADE_NO.'/',//异步通知地址
	"returnUrl" => $siteurl.'pay/vpay/return/'.TRADE_NO.'/'//同步跳转地址
);

$data['sign']=md5($data['payId'].$data['type'].$data['price'].$channel['appkey']);
$url = $channel['appid']."createOrder?".http_build_query($data); //支付页面

echo "<script>window.location.href = '{$url}'</script>";

